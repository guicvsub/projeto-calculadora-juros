//alert("it worked!");

// let nomeCompleto = prompt("Digite o seu nome Completo por favor:");

// console.log(`Seja bem-vindo ${nomeCompleto}`);

//dica para colocar comentário em várias linhas: CTRL + K + C

// function quadrado(numero){
//     return numero * numero;
// }

// quadrado()
/*
function oi(){

    console.log("Olá mundo!");
    let g = "CFCCT";
    console.log(g);
};

oi()*/

// function duplicar(){
//     let idade = prompt("Digite a sua idade")
//     console.log(idade * 2)
// }

// duplicar()

// EX:1 CRIE UMA FUNÇÃOQUE MUTIPLIQUE UM VALOR POR 100

/* function multiplicarPorCem(){
     let valor = prompt("Digite o valor que queira multiplicar por cem:");
     console.log(valor * 100);
 }

 multiplicarPorCem();
 */

// ex 2: formula juros simple JUROS = CAPITAL * TAXA * TEMPO /100

/*
function formulaJurosSimples(){
    console.log("Função de juros simples")
    let capital = Number(prompt("Digite o seu capital:"));
    let taxa = Number(prompt("Digite a taxa:"));
    let tempo = Number(prompt("Digite o tempo:"));
    let juros = Number(capital * taxa * tempo / 100);
    let montante = (capital + juros);

    console.log(`Querido internauta, voce pegou uma qunatia de R$ ${capital} e disse que iria pagar em um tempo de ${tempo} meses adicionado a uma taxa de ${taxa}%, portanto voce vai pagar juros de ${juros}. Caso o pagamento nao seja efetuado, seu nome estara no serasa`);
    
    console.log(`O valor total a ser pago sera de R$ ${montante}`)


}

formulaJurosSimples();

*/

// function jurosCompostos(){
//     console.log("Função de juros compostos")
//     let capital = Number(prompt("Digite o seu capital:"));
//     let taxa = Number(prompt("Digite a taxa:"));
//     let tempo = Number(prompt("Digite o tempo:"));
//     let montante = capital * (1 + taxa/100) ** tempo ;
    
//     console.log(`Ola Usuario, voce pegou uma quantia de R$ ${capital}, que ficaram aplicados por ${tempo} meses acrescidos a uma taxa de ${taxa} % ao mes . Portanto  montante foi de R$ ${montante}`);
// }

// jurosCompostos();

// function jurosCompostos(){
//      console.log("Função de juros compostos");
//      let form = document.getElementById("formulario");
//      let capital = document.getElementById("capital");
//      let taxa = document.getElementById("taxa");
//      let tempo = document.getElementById("tempo");

//      let montante = capital * (1 + taxa/100) ** tempo ;
// }
        
// function entrada(){
//     alert(document.getElementById("capital").value);
// }

// document.getElementById("capital").onkeypress = function(e) {
//     // 13 é a tecla <ENTER>. Se ela for pressionada, mostrar o valor
//     if (e.keyCode == 13) {
//         mostrarValor();
//         e.preventDefault();
//     }
// }

// // Evento que é executado ao clicar no botão de enviar
// document.getElementById("submit").onclick = function(e) {
//     mostrarValor();
//     e.preventDefault();
// }

// interagindo com o html e css

document.getElementById('calculate').addEventListener('click', function(){
    let capital = document.getElementById('capital').value;
    let taxa = (document.getElementById('taxa').value) / 100;
    let tempo = document.getElementById('tempo').value;

    let total = capital * (1 + taxa) ** tempo;

    document.getElementById('total').innerHTML = ("R$" + total.toFixed(2).replace('.' , ','));
});


